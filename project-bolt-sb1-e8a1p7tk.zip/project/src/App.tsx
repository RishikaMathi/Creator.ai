import React, { useState } from 'react';
import { Wand2, Sparkles, MessageSquare, Image, FileAudio, Loader2 } from 'lucide-react';
import OpenAI from 'openai';

type ContentType = 'text' | 'image' | 'audio';

interface GenerationRequest {
  prompt: string;
  type: ContentType;
  length?: 'short' | 'medium' | 'long';
  tone?: 'professional' | 'casual' | 'friendly';
}

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

function App() {
  const [prompt, setPrompt] = useState('');
  const [contentType, setContentType] = useState<ContentType>('text');
  const [length, setLength] = useState<'short' | 'medium' | 'long'>('medium');
  const [tone, setTone] = useState<'professional' | 'casual' | 'friendly'>('professional');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState('');
  const [error, setError] = useState('');

  const getMaxTokens = (length: string) => {
    switch (length) {
      case 'short': return 150;
      case 'long': return 750;
      default: return 350;
    }
  };

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError('');
    setGeneratedContent('');
    
    try {
      if (contentType === 'text') {
        const systemPrompt = `You are a content creator with a ${tone} tone. Generate content that is ${length} in length.`;
        
        const completion = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: prompt }
          ],
          max_tokens: getMaxTokens(length),
          temperature: tone === 'professional' ? 0.3 : 0.7,
        });

        setGeneratedContent(completion.choices[0].message.content || '');
      } else if (contentType === 'image') {
        const response = await openai.images.generate({
          model: "dall-e-3",
          prompt: prompt,
          n: 1,
          size: "1024x1024",
        });

        setGeneratedContent(response.data[0].url || '');
      } else if (contentType === 'audio') {
        const response = await openai.audio.speech.create({
          model: "tts-1",
          voice: "alloy",
          input: prompt,
        });

        const audio = await response.arrayBuffer();
        const blob = new Blob([audio], { type: 'audio/mpeg' });
        const url = URL.createObjectURL(blob);
        setGeneratedContent(url);
      }
    } catch (err) {
      console.error('Error generating content:', err);
      setError('Failed to generate content. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const contentTypeIcons = {
    text: <MessageSquare className="w-5 h-5" />,
    image: <Image className="w-5 h-5" />,
    audio: <FileAudio className="w-5 h-5" />
  };

  const renderGeneratedContent = () => {
    if (!generatedContent) return null;

    switch (contentType) {
      case 'image':
        return <img src={generatedContent} alt="Generated content" className="w-full rounded-lg" />;
      case 'audio':
        return (
          <audio controls className="w-full mt-4">
            <source src={generatedContent} type="audio/mpeg" />
            Your browser does not support the audio element.
          </audio>
        );
      default:
        return <div className="prose prose-invert">{generatedContent}</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <Wand2 className="w-8 h-8 text-purple-400" />
          <h1 className="text-3xl font-bold">AI Content Studio</h1>
        </div>

        <div className="bg-gray-800 rounded-xl p-6 shadow-xl">
          <div className="space-y-6">
            {/* Content Type Selection */}
            <div className="grid grid-cols-3 gap-4">
              {(['text', 'image', 'audio'] as ContentType[]).map(type => (
                <button
                  key={type}
                  onClick={() => setContentType(type)}
                  className={`flex items-center justify-center gap-2 p-4 rounded-lg transition
                    ${contentType === type 
                      ? 'bg-purple-600 text-white' 
                      : 'bg-gray-700 hover:bg-gray-600'}`}
                >
                  {contentTypeIcons[type]}
                  <span className="capitalize">{type}</span>
                </button>
              ))}
            </div>

            {/* Prompt Input */}
            <div>
              <label className="block text-sm font-medium mb-2">Prompt</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full h-32 px-4 py-2 rounded-lg bg-gray-700 focus:ring-2 focus:ring-purple-500 focus:outline-none"
                placeholder="Describe what you want to create..."
              />
            </div>

            {/* Options */}
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">Length</label>
                <select
                  value={length}
                  onChange={(e) => setLength(e.target.value as typeof length)}
                  className="w-full px-4 py-2 rounded-lg bg-gray-700 focus:ring-2 focus:ring-purple-500 focus:outline-none"
                >
                  <option value="short">Short</option>
                  <option value="medium">Medium</option>
                  <option value="long">Long</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Tone</label>
                <select
                  value={tone}
                  onChange={(e) => setTone(e.target.value as typeof tone)}
                  className="w-full px-4 py-2 rounded-lg bg-gray-700 focus:ring-2 focus:ring-purple-500 focus:outline-none"
                >
                  <option value="professional">Professional</option>
                  <option value="casual">Casual</option>
                  <option value="friendly">Friendly</option>
                </select>
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt}
              className="w-full py-3 px-6 rounded-lg bg-purple-600 hover:bg-purple-700 
                disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors
                flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Generate Content
                </>
              )}
            </button>

            {error && (
              <div className="p-4 bg-red-500/20 border border-red-500 rounded-lg text-red-200">
                {error}
              </div>
            )}
          </div>

          {/* Generated Content */}
          {generatedContent && (
            <div className="mt-8 p-6 bg-gray-700 rounded-lg">
              <h2 className="text-xl font-semibold mb-4">Generated Content</h2>
              {renderGeneratedContent()}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;